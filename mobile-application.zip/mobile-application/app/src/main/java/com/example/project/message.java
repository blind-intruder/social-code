package com.example.project;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.JsonArray;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

import static android.widget.Toast.LENGTH_SHORT;

public class message extends AppCompatActivity {
    private static final String TAG = "message";
    Handler handler = new Handler();
    int delay = 1000;
    Runnable runnable;
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        ActionBar actionBar = getSupportActionBar();
        Bundle b = getIntent().getExtras();
        actionBar.setTitle(b.getString("name"));
        get_msgs(b.getInt("id"));
        Button send = findViewById(R.id.send);
        send.setOnClickListener(new_send);
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Log.e(TAG, "running");
                get_new(b.getInt("id"));
            }
        }, 0, 1000);
    }

    private final View.OnClickListener new_send = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        public void onClick(View v) {
            EditText text=findViewById(R.id.new_msg_txt);
            if (text.getText().toString()!=""){
                Bundle b = getIntent().getExtras();
                add_sent(text.getText().toString());
                Integer id=b.getInt("id");
                send_msg(text.getText().toString(),id.toString());
                text.setText("");
            }
        }
    };

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void add_received(String msg){
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(2, 5, 250, 5);
        LinearLayout linearLayout = findViewById(R.id.msgs);

        TextView textView = new TextView(this);
        textView.setLayoutParams(params);
        textView.setBackground(getDrawable(R.drawable.received));
        textView.setPadding(25, 20, 20, 20);
        textView.setText(msg);
        linearLayout.addView(textView);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void add_sent(String msg){
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.setMargins(250, 5, 2, 5);
        params.gravity=Gravity.RIGHT;
        LinearLayout linearLayout = findViewById(R.id.msgs);
        TextView textView = new TextView(this);
        textView.setLayoutParams(params);

        textView.setBackground(getDrawable(R.drawable.sent));
        textView.setPadding(20, 20, 25, 20);
        textView.setText(msg);
        linearLayout.addView(textView);
    }


    public void get_msgs(Integer id){
        String url = "http://192.168.43.7/fyp/api/messenger/get-msgs/?id="+id;
        List<String> jsonResponses = new ArrayList<>();
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {

                    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray msgs=response.getJSONArray("msgs");
                            Log.e(TAG, "Success123");
                            for(int i = 0; i < msgs.length(); i++){
                                JSONObject obj = msgs.getJSONObject(i);
                                String text = obj.getString("text");
                                String type = obj.getString("type");
                                if (type.equals("sent")){
                                    add_sent(text);
                                }
                                else{
                                    add_received(text);
                                }
                            }
                        } catch (JSONException e) {
                            Log.e(TAG, "Success123");
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }){

            @Override
            public Map<String, String> getHeaders(){
                Map<String, String> headers = new HashMap<String, String>();
                String temp="";
                try {
                    FileInputStream fin = openFileInput("cookies.txt");
                    int a;
                    while( (a = fin.read()) != -1){
                        temp = temp + (char) a;
                    }
                    //Log.d(TAG,temp);
                    fin.close();
                } catch (FileNotFoundException e) {
                    Log.d(TAG,"file not found");
                    headers.put("Cookie", "null=null");
                    return headers;
                } catch (IOException e) {
                    Log.d(TAG,"file not found");
                    headers.put("Cookie", "null=null");
                }
                headers.put("Cookie", temp);
                return headers;
            }

        };

        requestQueue.add(jsonObjectRequest);
    }

    public void send_msg(String text,String f_id){
        String postUrl = "http://192.168.43.7/fyp/api/messenger/send/";
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        JSONObject postData = new JSONObject();
        try {
            postData.put("text",text);
            postData.put("f_id", f_id);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        byte[] data = postData.toString().getBytes();
        String base64 = Base64.encodeToString(data, Base64.DEFAULT);
        StringRequest jsonObjRequest = new StringRequest(Request.Method.POST,
                postUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject res = new JSONObject(response);
                            try {
                                String iscreated= res.getString("iscreated");
                                if (iscreated.equals("true")){
                                    Log.e(TAG, "msg sent");
                                }
                                else{
                                    Log.e(TAG, "msg not sent");
                                }
                            }
                            catch (Exception e){
                                Log.e(TAG, "msg not sent");
                            }
                        }
                        catch (Exception e){
                            Log.e(TAG, "msg not sent");
                        }


                        //Log.i(TAG,response);
                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("volley", "Error: " + error.getMessage());
                error.printStackTrace();
                Log.e(TAG, "Success");
            }
        }) {

            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded; charset=UTF-8";
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("data", base64);
                return params;
            }

            @Override
            public Map<String, String> getHeaders(){
                Map<String, String> headers = new HashMap<String, String>();
                String temp="";
                try {
                    FileInputStream fin = openFileInput("cookies.txt");
                    int a;
                    while( (a = fin.read()) != -1){
                        temp = temp + (char) a;
                    }
                    //Log.d(TAG,temp);
                    fin.close();
                } catch (FileNotFoundException e) {
                    Log.d(TAG,"file not found");
                    headers.put("Cookie", "null=null");
                    return headers;
                } catch (IOException e) {
                    Log.d(TAG,"file not found");
                    headers.put("Cookie", "null=null");
                }
                headers.put("Cookie", temp);
                return headers;
            }
        };

        requestQueue.add(jsonObjRequest);
    }

    public void get_new(Integer id){
        String url = "http://192.168.43.7/fyp/api/messenger/unread/?id="+id;
        List<String> jsonResponses = new ArrayList<>();
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {

                    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray msgs=response.getJSONArray("msgs");
                            Log.d(TAG,"new msg");
                            for(int i = 0; i < msgs.length(); i++){
                                JSONObject obj = msgs.getJSONObject(i);
                                String text = obj.getString("text");
                                //String type = obj.getString("type");
                                add_received(text);
                            }
                        } catch (JSONException e) {
                            Log.d(TAG,"not msg");
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                }){

            @Override
            public Map<String, String> getHeaders(){
                Map<String, String> headers = new HashMap<String, String>();
                String temp="";
                try {
                    FileInputStream fin = openFileInput("cookies.txt");
                    int a;
                    while( (a = fin.read()) != -1){
                        temp = temp + (char) a;
                    }
                    //Log.d(TAG,temp);
                    fin.close();
                } catch (FileNotFoundException e) {
                    Log.d(TAG,"file not found");
                    headers.put("Cookie", "null=null");
                    return headers;
                } catch (IOException e) {
                    Log.d(TAG,"file not found");
                    headers.put("Cookie", "null=null");
                }
                headers.put("Cookie", temp);
                return headers;
            }

        };

        requestQueue.add(jsonObjectRequest);
    }
}
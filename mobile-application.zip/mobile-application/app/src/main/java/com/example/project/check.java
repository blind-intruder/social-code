package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class check extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try
        {
            this.getSupportActionBar().hide();
        }
        catch (NullPointerException e){}
        setContentView(R.layout.activity_check);
        check();
    }

    private static final String TAG = "check";
    public void check(){
        String url = "http://192.168.43.7/fyp/api/actions/callback/";
        List<String> jsonResponses = new ArrayList<>();
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            String islogin = response.getString("islogin");
                            Log.d(TAG,"checking login:  "+islogin);
                            if (islogin.equals("false")){
                                show_login();
                            }
                            else{
                                show_friends();
                            }
                        } catch (JSONException e) {
                            show_login();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        show_login();
                    }
                }){

            @Override
            public Map<String, String> getHeaders(){
                Map<String, String> headers = new HashMap<String, String>();
                String temp="";
                try {
                    FileInputStream fin = openFileInput("cookies.txt");
                    int a;
                    while( (a = fin.read()) != -1){
                        temp = temp + Character.toString((char)a);
                    }
                    //Log.d(TAG,temp);
                    fin.close();
                } catch (FileNotFoundException e) {
                    Log.d(TAG,"file not found");
                    headers.put("Cookie", "null=null");
                    return headers;
                } catch (IOException e) {
                    Log.d(TAG,"file not found");
                    headers.put("Cookie", "null=null");
                }
                headers.put("Cookie", temp);
                return headers;
            }

        };

        requestQueue.add(jsonObjectRequest);
    }

    public void show_login(){
        Intent switchActivityIntent = new Intent(this, MainActivity.class);
        startActivity(switchActivityIntent);
    }

    public void show_friends(){
        Intent switchActivityIntent = new Intent(this, FriendsActivity.class);
        startActivity(switchActivityIntent);
    }
}
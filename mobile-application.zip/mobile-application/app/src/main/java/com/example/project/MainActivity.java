package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.snackbar.Snackbar;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.widget.Toast.LENGTH_SHORT;

public class MainActivity extends AppCompatActivity {
    private static final String cookies = "";
    public final Boolean[] flag = new Boolean[1];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try
        {
            this.getSupportActionBar().hide();
        }
        catch (NullPointerException e){}
        setContentView(R.layout.activity_main);
        Button login = findViewById(R.id.login_send);
        login.setOnClickListener(login_check);

    }


    private View.OnClickListener login_check = new View.OnClickListener() {
        public void onClick(View v) {
            EditText email=findViewById(R.id.login_email);
            EditText password=findViewById(R.id.login_password);
            String email_val=email.getText().toString();
            String pass_val=password.getText().toString();
            login(email_val,pass_val,v);
        }
    };
    private static final String TAG = "MainActivity";
    public void login(String email,String pass, View view) {
        String postUrl = "http://192.168.43.7/fyp/";
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        JSONObject postData = new JSONObject();
        try {
            postData.put("email",email);
            postData.put("password", pass);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        byte[] data = postData.toString().getBytes();
        String base64 = Base64.encodeToString(data, Base64.DEFAULT);
        StringRequest jsonObjRequest = new StringRequest(Request.Method.POST,
                postUrl,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                    try {
                        JSONObject res = new JSONObject(response);
                        try {
                            String islogin=res.getString("islogin").toString();
                            if (islogin.equals("true")){
                                Snackbar mySnackbar = Snackbar.make(view, "logged in", LENGTH_SHORT);
                                mySnackbar.show();
                                FileOutputStream fOut = openFileOutput("cookies.txt",Context.MODE_PRIVATE);
                                String cookies = res.getString("cookies").toString();
                                fOut.write(cookies.getBytes());
                                fOut.close();
                                show_friends();
                            }
                            else{
                                Snackbar mySnackbar = Snackbar.make(view, "incorrect login", LENGTH_SHORT);
                                mySnackbar.show();
                                show_friends();
                            }
                        }
                        catch (Exception e){
                            Snackbar mySnackbar = Snackbar.make(view, "Unable to parse JSON", LENGTH_SHORT);
                            mySnackbar.show();
                        }
                        //JSONObject islogin = json.getJSONObject("islogin");
                    }
                    catch (Exception e){
                        Snackbar mySnackbar = Snackbar.make(view, "Fail Request", LENGTH_SHORT);
                        mySnackbar.show();
                    }


                        //Log.i(TAG,response);
                    }
                }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("volley", "Error: " + error.getMessage());
                error.printStackTrace();
                Log.e(TAG, "Success");
            }
        }) {

            @Override
            public String getBodyContentType() {
                return "application/x-www-form-urlencoded; charset=UTF-8";
            }

            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("data", base64);
                return params;
            }

           // public Map<String, String> getHeaders() {

            //}

            @Override
            protected Response<String> parseNetworkResponse(NetworkResponse response) {
                // since we don't know which of the two underlying network vehicles
                // will Volley use, we have to handle and store session cookies manually
                //Log.i("response",response.headers.toString());
                Map<String, String> responseHeaders = response.headers;
                //String rawCookies = responseHeaders.get("Set-Cookie");
                String cookie=responseHeaders.get("Set-Cookie");
                Log.i("cookies",responseHeaders.toString());
                return super.parseNetworkResponse(response);
            }
        };

        requestQueue.add(jsonObjRequest);

    }

    public void show_friends(){
        Intent switchActivityIntent = new Intent(this, FriendsActivity.class);
        startActivity(switchActivityIntent);
    }
}
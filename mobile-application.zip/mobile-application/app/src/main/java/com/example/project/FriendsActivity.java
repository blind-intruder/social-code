package com.example.project;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.os.Build;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Transformation;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FriendsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Friends");
        setContentView(R.layout.friends);
        get_friends();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void show(String name,String id,String dp){
        LinearLayout linearLayout = findViewById(R.id.friends_s);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        params.setMargins(0, 5, 0, 0);
        TextView textView = new TextView(this);
        textView.setPadding(15, 30, 20, 30);
        textView.setLayoutParams(params);
        textView.setBackground(getDrawable(R.drawable.friend));
        textView.setText(name);
        textView.setTextSize(22);
        textView.setOnClickListener(new_chat);
        textView.setId(Integer.parseInt(id));
        LinearLayout parent = new LinearLayout(this);
        parent.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        parent.setOrientation(LinearLayout.HORIZONTAL);
        ImageView iv = new ImageView(this  );
        Picasso.with(this).load(dp).transform(new CircleTransform()).into(iv);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(155, 155);
        iv.setLayoutParams(layoutParams);
        iv.setPadding(0, 10, 0, 10);
        iv.requestLayout();
        parent.addView(iv);
        parent.addView(textView);
        parent.setBackground(getDrawable(R.drawable.friend));
        linearLayout.addView(parent);
    }

    public class CircleTransform implements Transformation {
        @Override
        public Bitmap transform(Bitmap source) {
            int size = Math.min(source.getWidth(), source.getHeight());

            int x = (source.getWidth() - size) / 2;
            int y = (source.getHeight() - size) / 2;

            Bitmap squaredBitmap = Bitmap.createBitmap(source, x, y, size, size);
            if (squaredBitmap != source) {
                source.recycle();
            }

            Bitmap bitmap = Bitmap.createBitmap(size, size, source.getConfig());

            Canvas canvas = new Canvas(bitmap);
            Paint paint = new Paint();
            BitmapShader shader = new BitmapShader(squaredBitmap,
                    Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            paint.setShader(shader);
            paint.setAntiAlias(true);

            float r = size / 2f;
            canvas.drawCircle(r, r, r, paint);

            squaredBitmap.recycle();
            return bitmap;
        }

        @Override
        public String key() {
            return "circle";
        }
    }

    private View.OnClickListener new_chat = new View.OnClickListener() {
        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        public void onClick(View v) {
            Log.d(TAG, String.valueOf(v.getId()));
            TextView textview = (TextView) v;
            Log.d(TAG, (String) ((TextView) v).getText());
            String name=(String) ((TextView) v).getText();
            show_message(name,v.getId());
        }
    };

    private static final String TAG = "FriendsActivity";
    public void get_friends(){
        String url = "http://192.168.43.7/fyp/api/messenger/friends/";
        List<String> jsonResponses = new ArrayList<>();

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {

                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("friends");
                            for(int i = 0; i < jsonArray.length(); i++){
                                JSONObject jsonObject = jsonArray.getJSONObject(i);
                                String name = jsonObject.getString("Name");
                                String id = jsonObject.getString("user_id");
                                String dp = jsonObject.getString("dp_link");
                                show(name,id,dp);
                                Log.i("name",name);
                            }
                        } catch (JSONException e) {
                            Log.i("name","not working");
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
                    }
                }){

            @Override
            public Map<String, String> getHeaders(){
                Map<String, String> headers = new HashMap<String, String>();
                String temp="";
                try {
                    FileInputStream fin = openFileInput("cookies.txt");
                    int a;
                    while( (a = fin.read()) != -1){
                        temp = temp + Character.toString((char)a);
                    }
                    //Log.d(TAG,temp);
                    fin.close();
                } catch (FileNotFoundException e) {
                    Log.d(TAG,"file not found");
                    headers.put("Cookie", "null=null");
                    return headers;
                } catch (IOException e) {
                    Log.d(TAG,"file not found");
                    headers.put("Cookie", "null=null");
                }
                headers.put("Cookie", temp);
                return headers;
            }

        };

        requestQueue.add(jsonObjectRequest);

    }

    public void show_message(String name,Integer id){
        Intent switchActivityIntent = new Intent(this, message.class);
        Bundle b = new Bundle();
        b.putInt("id", id);
        b.putString("name",name);
        switchActivityIntent.putExtras(b);
        startActivity(switchActivityIntent);
    }
}